package com.devali.repo.room;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import com.devali.entity.Room;

public interface CustomRoomRepository {

    List<String> findDistinctRoomTypes();

    List<Room> getAllAvailableRooms();

    public List<Room> findAvailableRooms(Date desiredCheckInDate, Date desiredCheckOutDate, String roomType);
}
