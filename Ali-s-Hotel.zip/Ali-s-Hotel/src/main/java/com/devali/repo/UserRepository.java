package com.devali.repo;

import java.util.Optional;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.devali.entity.User;

@Repository
public interface UserRepository extends MongoRepository<User, ObjectId> {

    boolean existsByEmail(String email);

    Optional<User> findByEmail(String email);
    
}
