package com.devali.repo.room;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.query.Criteria;

import com.devali.entity.Booking;
import com.devali.entity.Room;
import com.mongodb.BasicDBObject;


public class CustomRoomRepositoryImpl implements CustomRoomRepository{

@Autowired
private MongoTemplate mongoTemplate;

@Override
public List<String> findDistinctRoomTypes() {
    // Define the aggregation pipeline
    Aggregation aggregation = Aggregation.newAggregation(
        Aggregation.group("roomType"), // Group by roomType
        Aggregation.project().and("_id").as("roomType") // Project the _id field as roomType
    );

    // Execute the aggregation and map the results
    List<String> distinctRoomTypes = mongoTemplate.aggregate(aggregation, "rooms", BasicDBObject.class)
        .getMappedResults()
        .stream()
        .map(result -> result.getString("roomType")) // Extract the roomType field
        .collect(Collectors.toList());

    return distinctRoomTypes;
}




@Override
public List<Room> findAvailableRooms(Date desiredCheckInDate, Date desiredCheckOutDate, String roomType) {

    // Criteria to find bookings that overlap with desired dates
    Criteria dateOverlapCriteria = new Criteria().andOperator(
        Criteria.where("bookings.checkInDate").lt(desiredCheckOutDate),
        Criteria.where("bookings.checkOutDate").gt(desiredCheckInDate)
    );
    // System.out.println(dateOverlapCriteria.toString());

    // Criteria to match the desired roomType
    Criteria roomTypeCriteria = Criteria.where("roomType").is(roomType);

    // Criteria to check room availability
    Criteria availabilityCriteria = new Criteria().orOperator(
        Criteria.where("bookings").exists(false),
        Criteria.where("bookings").size(0),
        Criteria.where("bookings").not().elemMatch(dateOverlapCriteria)
    );

    // Combine roomTypeCriteria and availabilityCriteria
    Criteria matchCriteria = new Criteria().andOperator(
        roomTypeCriteria,
        availabilityCriteria
    );

    // Build the aggregation pipeline
    Aggregation aggregation = Aggregation.newAggregation(
        Aggregation.lookup("bookings", "_id", "room", "bookings"),
        Aggregation.match(matchCriteria),
        Aggregation.project("roomType", "roomPrice", "roomPhotoUrl", "roomDescription")
    );


    // Execute the aggregation
    AggregationResults<Room> results = mongoTemplate.aggregate(aggregation, "rooms", Room.class);

    return results.getMappedResults();
}


    

    @Override
    public List<Room> getAllAvailableRooms() {
        // Aggregation pipeline to find rooms with no associated bookings
        Aggregation aggregation = Aggregation.newAggregation(
            Aggregation.lookup("bookings", "_id", "room.$id", "bookings"),
            Aggregation.match(Criteria.where("bookings").size(0))
        );
    
        AggregationResults<Room> results = mongoTemplate.aggregate(aggregation, "rooms", Room.class);
        List<Room> availableRooms = results.getMappedResults();
    
        // Debugging: Print the available rooms details
        System.out.println("Number of available rooms: " + availableRooms.size());
        for (Room room : availableRooms) {
            System.out.println(room);
        }
    
        return availableRooms;
    }
    
}


    
