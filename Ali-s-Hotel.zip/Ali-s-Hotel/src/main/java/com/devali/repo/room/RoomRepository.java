package com.devali.repo.room;


import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

import com.devali.entity.Room;

public interface RoomRepository extends MongoRepository<Room,ObjectId>, CustomRoomRepository{

    

    
}
