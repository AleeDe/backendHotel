package com.devali.dto;

import java.util.ArrayList;
import java.util.List;

import org.bson.types.ObjectId;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserDTO {

    ObjectId id;
    private String stringId;
    private String name;
    private String email;
    private String role;
    private String phoneNumber;
    private List<BookingDTO> bookings= new ArrayList<>();
    
}
