package com.devali.dto;


import java.util.Date;

import org.bson.types.ObjectId;


import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;


@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BookingDTO {

    private ObjectId id;
    private String stringId;
    private Date checkInDate;
    private Date checkOutDate;
    private int numOfAdults;
    private int numOfChildren;
    private int totalNumOfGuest;
    private String bookingConfirmationCode;
    private RoomDTO room;
    private UserDTO user;
    
}
