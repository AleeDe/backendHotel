package com.devali.entity;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;



import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Document(collection = "rooms")
public class Room {
    
    @Id
    private ObjectId id;

    private String roomType;
    private BigDecimal roomPrice;
    private String roomPhotoUrl;
    private String roomDescription;

    private String stringId;
    
    public String getStringId() {
        return id != null ? id.toHexString() : null;
    }


    @DBRef
    private List<Booking> bookings= new ArrayList<>();


    @Override
    public String toString() {
        return "{" +
            " id='" + getId() + "'" +
            ", roomType='" + getRoomType() + "'" +
            ", roomPrice='" + getRoomPrice() + "'" +
            ", roomPhotoUrl='" + getRoomPhotoUrl() + "'" +
            ", roomDescription='" + getRoomDescription() + "'" +
            "}";
    }

}
