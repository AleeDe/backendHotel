package com.devali.entity;

import java.time.LocalDate;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.Objects;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Document(collection = "bookings")
public class Booking {
    
    @Id
    private ObjectId id;

    @NotNull(message = "Check-in date is required")
    private Date checkInDate;

    @Future(message = "Check-out date must be in the future")
    private Date checkOutDate;

    @Min(value = 1, message = "Number of adults must be at least 1")
    private int numOfAdults;

    @Min(value = 0, message = "Number of children must be at least 0")
    private int numOfChildren;

    private int totalNumOfGuest;

    private String bookingConfirmationCode;


    @DBRef
    private Room room;


    @DBRef
    private User roomUser;

    private String stringId;
    
    public String getStringId() {
        return id != null ? id.toHexString() : null;
    }

    public void calTotalNumOfGuest() {
        this.totalNumOfGuest = numOfAdults + numOfChildren;
    }



    public void setNumOfAdults(int numOfAdults) {
        this.numOfAdults = numOfAdults;
        calTotalNumOfGuest();
    }

   

    public void setNumOfChildren(int numOfChildren) {
        this.numOfChildren = numOfChildren;
        calTotalNumOfGuest();
    }


    @Override
    public String toString() {
        return "{" +
            " id='" + getId() + "'" +
            ", checkInDate='" + getCheckInDate() + "'" +
            ", checkOutDate='" + getCheckOutDate() + "'" +
            ", numOfAdults='" + getNumOfAdults() + "'" +
            ", numOfChildren='" + getNumOfChildren() + "'" +
            ", totalNumOfGuest='" + getTotalNumOfGuest() + "'" +
            ", bookingConfirmationCode='" + getBookingConfirmationCode() + "'" +
            "}";
    }

   
}
