package com.devali.service.interfac;

import org.bson.types.ObjectId;

import com.devali.dto.Response;
import com.devali.entity.Booking;

public interface IBookingService {
    
    Response saveBooking(String roomId, String userId, Booking bookingRequest);

    Response findBookingByConfirmationCode(String confirmationCode);

    Response getAllBookings();

    Response cancelBooking(String bookingId);


}
