package com.devali.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.devali.dto.BookingDTO;
import com.devali.dto.Response;
import com.devali.dto.RoomDTO;
import com.devali.dto.UserDTO;
import com.devali.entity.Booking;
import com.devali.entity.Room;
import com.devali.entity.User;
import com.devali.exception.OurException;
import com.devali.repo.BookingRepository;
import com.devali.repo.UserRepository;
import com.devali.repo.room.RoomRepository;
import com.devali.service.interfac.IBookingService;
import com.devali.service.interfac.IRoomService;
import com.devali.utils.Utils;

@Service
public class BookingService implements IBookingService{

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private IRoomService roomService;

    @Autowired
    private RoomRepository roomRepository;

    @Autowired
    private UserRepository userRepository;

    @Override
public Response saveBooking(String roomId, String userId, Booking bookingRequest) {
    Response response = new Response();
    try {
        if (bookingRequest.getCheckOutDate().before(bookingRequest.getCheckInDate())) {
            throw new IllegalArgumentException("Check-out date should be after check-in date.");
        }

        // Fetch the room and user from their repositories
        ObjectId objectIdRoom = new ObjectId(roomId);
        ObjectId objectIdUser = new ObjectId(userId);
        Room room = roomRepository.findById(objectIdRoom)
            .orElseThrow(() -> new OurException("Room not found"));
        User user = userRepository.findById(objectIdUser)
            .orElseThrow(() -> new OurException("User not found"));

        // Fetch existing bookings for the room
        List<Booking> existingBookings = bookingRepository.findByRoomId(objectIdRoom);

        // Ensure existingBookings is not null and contains no null entries
        if (existingBookings == null) {
            existingBookings = new ArrayList<>();
        } else {
            existingBookings.removeIf(Objects::isNull);
        }

        // Check room availability
        if (!roomIsAvailable(bookingRequest, existingBookings)) {
            throw new OurException("Room is not available for the selected dates.");
        }

        // Set additional booking details
        String confirmationCode = Utils.generateRandomConfirmationCode(10);
        bookingRequest.setBookingConfirmationCode(confirmationCode);
        bookingRequest.setRoom(room);
        bookingRequest.setRoomUser(user);
        
        // Save the booking
        bookingRepository.save(bookingRequest);
        user.getBookings().add(bookingRequest);
        room.getBookings().add(bookingRequest);
        System.out.println("satart");
        System.out.println("User"+user);
        System.out.println("Room:" +room);
        userRepository.save(user);
        roomRepository.save(room);
        System.out.println("end");


        // Prepare the response
        response.setStatusCode(201);
        response.setBookingConfirmationCode(confirmationCode);
        response.setMessage("Booking saved successfully.");
    } catch (OurException e) {
        response.setStatusCode(404);
        response.setMessage(e.getMessage());
    } catch (Exception e) {
        response.setStatusCode(500);
        response.setMessage("Error while saving the booking: " + e.getMessage());
    }
    return response;
}

private boolean roomIsAvailable(Booking bookingRequest, List<Booking> existingBookings) {
    return existingBookings.stream()
        .noneMatch(existingBooking -> {
            // Check if the requested dates overlap with any existing booking
            boolean isOverlap = !bookingRequest.getCheckInDate().after(existingBooking.getCheckOutDate())
                && !bookingRequest.getCheckOutDate().before(existingBooking.getCheckInDate());
            System.out.println("Checking overlap with booking ID " + existingBooking.getId() + ": " + isOverlap);
            return isOverlap;
        });
}


    @Override
    public Response findBookingByConfirmationCode(String confirmationCode) {
        Response response = new Response();
        try {
            Booking booking = bookingRepository.findByBookingConfirmationCode(confirmationCode).orElseThrow(()-> new OurException("Booking not found"));
            BookingDTO bookingDTO = Utils.mapBookingEntityToBookingDTO(booking);


            
            response.setStatusCode(200);
            response.setMessage("Booking found");
            response.setBooking(bookingDTO);
            response.setRoom(Utils.mapRoomEntityToRoomDTO(booking.getRoom()));
            response.setUser(Utils.mapUserEntityToUserDTO(booking.getRoomUser()));
            
        } catch (OurException e) {
            response.setStatusCode(404);
            response.setMessage(e.getMessage());
        }
        catch (Exception e) {
            response.setStatusCode(500);
            response.setMessage("Error while  getting by confirmation code"+e.getMessage());
        }
        return response;
    }

    @Override
    public Response getAllBookings() {
        Response response = new Response();
        try {
            List<Booking> bookings = bookingRepository.findAll(Sort.by(Sort.Direction.DESC, "id"));
            List<BookingDTO> bookingDTOs = Utils.mapBookingEntityToBookingListDTO(bookings);
            
            response.setStatusCode(200);
            response.setMessage("Bookings found");
            response.setBookingList(bookingDTOs);
        } catch (OurException e) {
            response.setStatusCode(404);
            response.setMessage(e.getMessage());
        }
        catch (Exception e) {
            response.setStatusCode(500);
            response.setMessage("Error while  getting all the booking"+e.getMessage());
        }
        return response;
    }

    @Override
    public Response cancelBooking(String bookingId) {
        ObjectId objectIdBooking = new ObjectId(bookingId);
        Response response = new Response();
        try {
            Booking booking = bookingRepository.findById(objectIdBooking).orElseThrow(()-> new OurException("Booking not found"));
            bookingRepository.delete(booking);
            
            response.setStatusCode(200);
            response.setMessage("Booking cancelled");
        } catch (OurException e) {
            response.setStatusCode(404);
            response.setMessage(e.getMessage());
        }
        catch (Exception e) {
            response.setStatusCode(500);
            response.setMessage("Error while  cancelling the booking"+e.getMessage());
        }
        return response;
    }
    
   
    
    
}
