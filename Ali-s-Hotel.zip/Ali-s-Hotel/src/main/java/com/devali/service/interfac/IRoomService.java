package com.devali.service.interfac;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.web.multipart.MultipartFile;

import com.devali.dto.Response;

public interface IRoomService {

    Response addNewRoom(MultipartFile photo, String roomType, BigDecimal roomPrice, String description);

    List<String> getRoomTypes();

    Response getAllRooms();
    
    Response deleteRoom(String id);

    Response updateRoom(String id, MultipartFile photo, String roomType, BigDecimal roomPrice, String description);

    Response getRoomById(String id);

    Response getAvailableRoomsByDateAndType(Date checkInDate, Date checkOutDate, String roomType);

    Response getAllAvailableRooms();
    
}
