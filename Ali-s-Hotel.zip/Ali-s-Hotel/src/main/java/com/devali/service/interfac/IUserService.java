package com.devali.service.interfac;
import org.bson.types.ObjectId;

import com.devali.dto.LoginRequest;
import com.devali.dto.Response;
import com.devali.entity.User;

public interface IUserService {
    Response register(User user);

    Response login(LoginRequest loginRequest);

    Response getAllUsers();

    Response getUserBookingHistory(String id);

    Response getUserById(String id);

    Response deleteUser(String id);

    Response getMyInfo(String email);

}
