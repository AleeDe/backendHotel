package com.devali.service.impl;

import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.devali.dto.LoginRequest;
import com.devali.dto.Response;
import com.devali.dto.UserDTO;
import com.devali.entity.Booking;
import com.devali.entity.User;
import com.devali.exception.OurException;
import com.devali.repo.BookingRepository;
import com.devali.repo.UserRepository;
import com.devali.service.interfac.IUserService;
import com.devali.utils.JWTUtils;
import com.devali.utils.Utils;



@Service
public class UserService implements IUserService{

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JWTUtils jwtUtils;

    @Autowired
    private AuthenticationManager authenticationManager;
    @Autowired
    private BookingRepository bookingRepository;

    @Override
    public Response register(User user) {
        

        Response response = new Response();
        try {
            if(user.getRole() == null || user.getRole().isEmpty()) {
                user.setRole("USER");
            }

            if(userRepository.existsByEmail(user.getEmail())) {
                throw new OurException(user.getEmail()+" "+"Email already exists");
            }

            if(user.getPassword() != null && !user.getPassword().isEmpty())
            user.setPassword(passwordEncoder.encode(user.getPassword()));


            User savedUser = userRepository.save(user);
            UserDTO userDTO = Utils.mapUserEntityToUserDTO(savedUser);

            response.setStatusCode(201);
            response.setUser(userDTO);
            response.setMessage("User registered successfully");
        } catch (OurException e) {
            response.setStatusCode(409);
            response.setMessage(e.getMessage());
        }
        catch (Exception e) {
            response.setStatusCode(500);
            response.setMessage("Error while registering user "+e.getMessage());
        }
        return response;
    }

    @Override
    public Response login(LoginRequest loginRequest) {
        Response response = new Response();
        try {
            
            authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(loginRequest.getEmail(), loginRequest.getPassword()));
            User user = userRepository.findByEmail(loginRequest.getEmail()).orElseThrow(()->new OurException(loginRequest.getEmail()+" "+"Email not found"));
            String token=jwtUtils.generateToken(user);


            response.setToken(token);
            response.setExpirationTime("7 days");
            response.setRole(user.getRole());
            response.setMessage("successfully logged in");
            response.setStatusCode(200);
        } catch (OurException e) {
            response.setStatusCode(404);
            response.setMessage(e.getMessage());
        }
        catch (Exception e) {
            response.setStatusCode(500);
            response.setMessage("Error while Loginng user "+e.getMessage());
        }
        return response;
    }

    @Override
    public Response getAllUsers() {
        Response response = new Response();
        try {
            List<User> users = userRepository.findAll();
            List<UserDTO> userDTOs = Utils.mapUserEntityToUserListDTO(users);

            response.setStatusCode(200);
            response.setUserList(userDTOs);
            response.setMessage("Users fetched successfully");
        }
        catch (Exception e) {
            response.setStatusCode(500);
            response.setMessage("Error while getting all user "+e.getMessage());
        }
        return response;
    }

    @Override
    public Response getUserBookingHistory(String id) {
        ObjectId objectIdUser = new ObjectId(id);

        Response response = new Response();
        try {
            User user = userRepository.findById(objectIdUser).orElseThrow(()->new OurException("User not found"));
            System.out.println(user);
            UserDTO userDTOs = Utils.mapUserEntityToUserDtoPlusUserBookingAndRoom(user);
            // List<Booking> booking = bookingRepository.findByUserId(objectIdUser)

            response.setStatusCode(200);
            response.setUser(userDTOs);
            response.setMessage("Users fetched successfully");
            // response.setBookingList(Utils.mapBookingEntityToBookingListDTO());
        } catch (OurException e) {
            response.setStatusCode(404);
            response.setMessage(e.getMessage());
        }
        catch (Exception e) {
            response.setStatusCode(500);
            response.setMessage("Error while getting User Booking History "+e.getMessage());
        }
        return response;
    }

    @Override
    public Response getUserById(String id) {
        ObjectId objectIdUser = new ObjectId(id);
        Response response = new Response();
        try {
            User user = userRepository.findById(objectIdUser).orElseThrow(()->new OurException("User not found"));
            UserDTO userDTOs = Utils.mapUserEntityToUserDTO(user);

            response.setStatusCode(200);
            response.setUser(userDTOs);
            response.setMessage("Users fetched successfully");
        } catch (OurException e) {
            response.setStatusCode(404);
            response.setMessage(e.getMessage());
        }
        catch (Exception e) {
            response.setStatusCode(500);
            response.setMessage("Error while getting byuserId "+e.getMessage());
        }
        return response;
    }

    @Override
    public Response deleteUser(String id) {
        ObjectId objectIdUser = new ObjectId(id);
        Response response = new Response();
        try {
            User user = userRepository.findById(objectIdUser).orElseThrow(()->new OurException("User not found"));
            userRepository.delete(user);
            response.setStatusCode(204);
            response.setMessage("User deleted successfully");
        } catch (OurException e) {
            response.setStatusCode(404);
            response.setMessage(e.getMessage());
        }
        catch (Exception e) {
            response.setStatusCode(500);
            response.setMessage("Error while deleting user "+e.getMessage());
        }
        return response;
    }

    @Override
    public Response getMyInfo(String email) {
        Response response = new Response();
        try {
            User user = userRepository.findByEmail(email).orElseThrow(()->new OurException("User not found"));
            UserDTO userDTO = Utils.mapUserEntityToUserDTO(user);
            response.setStatusCode(200);
            response.setUser(userDTO);
            response.setMessage("User Information fetched successfully");
        } catch (OurException e) {
            response.setStatusCode(404);
            response.setMessage(e.getMessage());
        }
        catch (Exception e) {
            response.setStatusCode(500);
            response.setMessage("Error while getting user info by email "+e.getMessage());
        }
        return response;
    }
    
}
