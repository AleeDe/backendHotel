package com.devali.service.impl;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.devali.dto.Response;
import com.devali.dto.RoomDTO;
import com.devali.dto.UserDTO;
import com.devali.entity.Room;
import com.devali.entity.User;
import com.devali.exception.OurException;
import com.devali.repo.BookingRepository;
import com.devali.repo.room.RoomRepository;
import com.devali.service.AwsS3Service;
import com.devali.service.interfac.IRoomService;
import com.devali.utils.Utils;


@Service
public class RoomService implements IRoomService{

    @Autowired
    private RoomRepository roomRepository;

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private AwsS3Service awsS3Service;

    @Override
    public Response addNewRoom(MultipartFile photo, String roomType, BigDecimal roomPrice, String description) {
        Response response = new Response();
        try {
            String photoUrl = awsS3Service.saveImageToS3(photo);

            Room room = new Room();
            room.setId(ObjectId.get()); // Generate new ObjectId
            room.setStringId(room.getId().toHexString());
            room.setRoomType(roomType);
            room.setRoomPrice(roomPrice);
            room.setRoomDescription(description);
            room.setRoomPhotoUrl(photoUrl);

            Room savedRoom = roomRepository.save(room);
            RoomDTO roomDTO = Utils.mapRoomEntityToRoomDTO(savedRoom);
            
            response.setRoom(roomDTO);
            response.setStatusCode(201);
            response.setMessage("Room added successfully");
            
        }
        catch (Exception e) {
            response.setStatusCode(500);
            response.setMessage("Error while  saving room "+e.getMessage());
        }
        return response;
    
    }

    @Override
    public List<String> getRoomTypes() {
            return roomRepository.findDistinctRoomTypes();  
    }

    @Override
    public Response getAllRooms() {
        Response response = new Response();
        try {
            List<Room> rooms = roomRepository.findAll(Sort.by(Sort.Direction.DESC, "id"));

            List<RoomDTO> roomDTOs = Utils.mapRoomEntityToRoomListDTO(rooms);


            response.setRoomList(roomDTOs);
            response.setStatusCode(200);
            response.setMessage("Rooms fetched successfully");
        }
        catch (Exception e) {
            response.setStatusCode(500);
            response.setMessage("Error while getting all rooms "+e.getMessage());
        }
        return response;
    }
    

    @Override
    public Response deleteRoom(String id) {
        ObjectId objectIdRoom = new ObjectId(id);
        Response response = new Response();
        try {
            Room room = roomRepository.findById(objectIdRoom).orElseThrow(() -> new OurException("Room not found"));
            roomRepository.delete(room);
            response.setStatusCode(204);
            response.setMessage("Room deleted successfully");
        } catch (OurException e) {
            response.setStatusCode(404);
            response.setMessage(e.getMessage());
        }
        catch (Exception e) {
            response.setStatusCode(500);
            response.setMessage("Error while  Room deleted"+e.getMessage());
        }
        return response;
    }
    

    @Override
    public Response updateRoom(String id, MultipartFile photo, String roomType, BigDecimal roomPrice,
            String description) {
                ObjectId objectIdRoom = new ObjectId(id);
                Response response = new Response();
                try {
                    String imageUrl= null;

                    if(photo != null && !photo.isEmpty()) {
                        imageUrl = awsS3Service.saveImageToS3(photo);
                    }

                    Room updatedRoom = roomRepository.findById(objectIdRoom).orElseThrow(() -> new OurException("Room not found"));
                    if(roomType != null) {
                        updatedRoom.setRoomType(roomType);
                    }
                    if(roomPrice != null) {
                        updatedRoom.setRoomPrice(roomPrice);
                    }
                    if(description != null) {
                        updatedRoom.setRoomDescription(description);
                    }
                    if(imageUrl != null) {
                        updatedRoom.setRoomPhotoUrl(imageUrl);
                    }


                    roomRepository.save(updatedRoom);
                    RoomDTO roomDTO = Utils.mapRoomEntityToRoomDTO(updatedRoom);


                    response.setRoom(roomDTO);
                    response.setStatusCode(200);
                    response.setMessage("Room updated successfully");
                } catch (OurException e) {
                    response.setStatusCode(404);
                    response.setMessage(e.getMessage());
                }
                catch (Exception e) {
                    response.setStatusCode(500);
                    response.setMessage("Error while  Room updated"+e.getMessage());
                }
                return response;
    }

    @Override
    public Response getRoomById(String id) {
        ObjectId objectIdRoom = new ObjectId(id);
        Response response = new Response();
        try {
            Room room = roomRepository.findById(objectIdRoom).orElseThrow(() -> new OurException("Room not found"));
            RoomDTO roomDTO = Utils.mapRoomEntityToRoomDTO(room);
            response.setRoom(roomDTO);
            response.setStatusCode(200);
            response.setMessage("Room fetched by Id successfully");
        } catch (OurException e) {
            response.setStatusCode(404);
            response.setMessage(e.getMessage());
        }
        catch (Exception e) {
            response.setStatusCode(500);
            response.setMessage("Error while  Room fetched by Id"+e.getMessage());
        }
        return response;
    }

    @Override
    public Response getAvailableRoomsByDateAndType(Date checkInDate, Date checkOutDate, String roomType) {
        Response response = new Response();
        try {
            List<Room> rooms = roomRepository.findAvailableRooms(checkInDate, checkOutDate, roomType);
            List<RoomDTO> roomDTOs = Utils.mapRoomEntityToRoomListDTO(rooms);

            response.setRoomList(roomDTOs);
            response.setStatusCode(200);
            response.setMessage("Rooms fetched  successfully");
        } catch (OurException e) {
            response.setStatusCode(404);
            response.setMessage(e.getMessage());
        }
        catch (Exception e) {
            response.setStatusCode(500);
            response.setMessage("Error while  Rooms fetched"+e.getMessage());
        }
        return response;
    }

    @Override
    public Response getAllAvailableRooms() {
        Response response = new Response();
        try {
            List<Room> rooms = roomRepository.getAllAvailableRooms();
            List<RoomDTO> roomDTOs = Utils.mapRoomEntityToRoomListDTO(rooms);

            response.setRoomList(roomDTOs);
            response.setStatusCode(200);
            response.setMessage("Rooms fetched  successfully");

            response.setRoomList(roomDTOs);
        } catch (OurException e) {
            response.setStatusCode(404);
            response.setMessage(e.getMessage());
        }
        catch (Exception e) {
            response.setStatusCode(500);
            response.setMessage("Error while  Rooms fetched"+e.getMessage());
        }
        return response;
    }
    
}
